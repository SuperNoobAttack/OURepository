/*
* Jacob Longar
* Program 1
* Concurrent and Distributed programming
*/  

import java.net.ServerSocket;
import java.net.Socket;
import java.io.PrintWriter;
import java.io.Writer;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GuessServer {
    public static void main(String[] args) throws IOException {
        
        if (args.length != 1) {
            System.err.println("Usage: java GuessServer <port number>");
            System.exit(1);
        }

        //error checking for port number
        final String regex = "(\\d+)";
        final Pattern pattern = Pattern.compile(regex);
        Matcher matcher1 = pattern.matcher(args[0]);
        int portNumber = 0; //initialized to default value first.
        if (matcher1.find()) {
            portNumber = Integer.parseInt(args[0]);
        }
        else {
            System.err.println("Please Enter a number for the port number.");
        }
        
        try (
            ServerSocket serverSocket =
                new ServerSocket(Integer.parseInt(args[0]));
            Socket clientSocket = serverSocket.accept();
            PrintWriter out = //information taken out of the client socket
                new PrintWriter(clientSocket.getOutputStream(), true);                   
            BufferedReader in = new BufferedReader(
                new InputStreamReader(clientSocket.getInputStream()));
        ) {
            out.println("Server: Welcome. Guess a number [0-10]");

            //initializing variables
            String inputLine;
            Random rnd = new Random();
            int correctAnswer = rnd.nextInt() % 10;
            correctAnswer = Math.abs(correctAnswer);
            int guessNumber = 0;
            int counter = 0;

            //checking if the answer is correct
            while (guessNumber != correctAnswer) {
                inputLine = in.readLine();

                Matcher matcher2 = pattern.matcher(inputLine);
                //error checking for user input.
                if (matcher2.find()) {
                    guessNumber = Integer.parseInt(inputLine);
                }
                else {
                    System.err.println("Please enter a number.");
                }
                guessNumber = Integer.parseInt(inputLine);
                if (guessNumber > correctAnswer) {
                    out.println("Server: Lower.");
                    counter++;
                }
                if (guessNumber < correctAnswer) {
                    out.println("Server: Higher.");
                    counter++;
                }
            }
            //advancing our counter one more time and printing final message.
            counter++;
            out.println("Server: Correct. " + counter + " guesses.");
        } catch (IOException e) {
            System.out.println("Exception caught when trying to listen on port "
                + portNumber + " or listening for a connection");
            System.out.println(e.getMessage());
        }
    }
}
