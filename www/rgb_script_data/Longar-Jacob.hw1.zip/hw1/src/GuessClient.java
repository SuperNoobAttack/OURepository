/*
* Jacob Longar
* Program 1
* Concurrent and Distributed programming
*/

import java.io.PrintWriter;
import java.io.Writer;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.String;
import java.net.Socket;
import java.net.ServerSocket;
import java.net.UnknownHostException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GuessClient {
    public static void main(String[] args) throws IOException {
        
        if (args.length != 2) {
            System.err.println(
                "Usage: java GuessClient <host name> <port number>");
            System.exit(1);
        }

        String hostName = args[0];

        //error checking for port number
        final String regex = "(\\d+)";
        final Pattern pattern = Pattern.compile(regex);
        final Matcher matcher = pattern.matcher(args[1]);
        int portNumber = 0; //initialized to default value first.
        if (matcher.find()) {
            portNumber = Integer.parseInt(args[1]);
        }
        else {
            System.err.println("Please Enter a number for the port number.");
        }

        try (
            Socket echoSocket = new Socket(hostName, portNumber);
            PrintWriter out =
                new PrintWriter(echoSocket.getOutputStream(), true);
            BufferedReader in =
                new BufferedReader(
                    new InputStreamReader(echoSocket.getInputStream()));
            BufferedReader stdIn =
                new BufferedReader(
                    new InputStreamReader(System.in))
        ) {
            String userInput;
            int guessNumber;
            String temp;
            System.out.println(in.readLine());
            while ((userInput = stdIn.readLine()) != null) {
                out.println(userInput);
                temp = in.readLine();
                System.out.println(temp);
                if (temp.contains("Correct.")) {
                    System.exit(0);
                }
            }
        } catch (UnknownHostException e) {
            System.err.println("Don't know about host " + hostName);
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Couldn't get I/O for the connection to " +
                hostName);
            System.exit(1);
        } 
    }
}
